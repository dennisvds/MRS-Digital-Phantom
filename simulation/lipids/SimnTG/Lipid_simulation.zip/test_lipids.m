
n = 2048;
sw = 2000;
linewidth = 5;
Bfield = 3;
TE = 35;
seq = 'press';
cf = 128.2;
[out, out_components, names] = create_lipids(n, sw, Bfield, linewidth, TE, seq, cf);